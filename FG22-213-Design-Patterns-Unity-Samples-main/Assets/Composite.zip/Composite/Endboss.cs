using UnityEngine;

namespace Composite
{
    public class Endboss : MonoBehaviour
    {
        public Weakpoint[] weakpoints;
        // public float health;
    }
}