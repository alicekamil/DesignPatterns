using UnityEngine;

namespace Composite
{
    public interface IClanMember {
        public string Clan { get; }
    }
    
    // attack buildings owned not by players of our clan if they are not immune
    // attack creeps if they're not friendly
    // attack endbosses' weakpoints, but not environment's weakpoints
    // attack players from other clans
            
    // we want to attack the closest of these
    public interface IAITarget
    {
        int Health { get; }
        string AssociatedClan { get; }
        bool Attackable { get; }
        Vector3 Position { get; }
    }
    
    public class AI : MonoBehaviour
    {
        public GameObject target;
        public void Update()
        {
            if (target == null)
            {
                target = PickTarget();
            }
        }

        GameObject PickTarget()
        {
            var zone = Zone.Current;
            // attack buildings owned not by players of our clan if they are not immune
            // attack creeps if they're not friendly
            // attack endbosses' weakpoints, but not environment's weakpoints
            // attack players from other clans
            
            // we want to attack the closest of these
            return default;
        }
    }
}