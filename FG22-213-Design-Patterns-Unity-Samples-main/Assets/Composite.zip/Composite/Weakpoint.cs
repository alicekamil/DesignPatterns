using UnityEngine;

namespace Composite
{
    public class Weakpoint
    {
        public bool covered;
        public Vector3 offset;
    }
}