using UnityEngine;

namespace Composite
{
    public class Environment : MonoBehaviour
    {
        public Weakpoint[] weakpoints;
    }
}