using System.Collections.Generic;
using UnityEngine;

namespace Composite
{
    public class Zone : MonoBehaviour
    {
        public static Zone Current { get; }
        public Building[] buildings;
        public Creep[] creeps;
        public Queue<Endboss> endbosses;
        public List<Player> players;
        public HashSet<Environment> environments;
    }
}