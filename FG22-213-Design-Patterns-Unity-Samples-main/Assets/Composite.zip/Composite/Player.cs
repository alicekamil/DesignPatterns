using UnityEngine;

namespace Composite
{
    public class Player : MonoBehaviour, IAITarget
    {
        public int health;
        public int bonusHealth;
        public string clan;
        
        // DANGER HERE: THE AI CAN'T IDENTIFY ITSELF!!
        # region IAITarget

        int IAITarget.Health => health;
        string IAITarget.AssociatedClan => clan;
        bool IAITarget.Attackable => true;
        Vector3 IAITarget.Position => transform.position;

        #endregion // IAITarget
    }
}