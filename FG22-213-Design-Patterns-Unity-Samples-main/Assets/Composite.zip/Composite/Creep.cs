using UnityEngine;

namespace Composite
{
    public class Creep : MonoBehaviour, IAITarget
    {
        public float health;
        public bool friendly;
        
        # region IAITarget

        int IAITarget.Health => Mathf.CeilToInt(health);
        string IAITarget.AssociatedClan => default;
        bool IAITarget.Attackable => !friendly;
        Vector3 IAITarget.Position => transform.position;

        #endregion // IAITarget
    }
}