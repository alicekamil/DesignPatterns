using UnityEngine;

namespace Composite
{
    public class Foo
    {
        public static void Bar(Building building)
        {
        }
    }
    
    public class Building : MonoBehaviour, IAITarget
    {
        public int health;
        public bool immune;
        public Player player;
        
        # region IAITarget

        int IAITarget.Health => health;
        string IAITarget.AssociatedClan => player?.clan;
        bool IAITarget.Attackable => !immune;
        Vector3 IAITarget.Position => transform.position;

        #endregion // IAITarget
    }
}